<?php $this->load->view('template/head'); ?>


<div class="col-md-12 grid-margin">
  <div class="card-body">
    <div class="row">
      <div class="d-sm-flex align-items-baseline report-summary-header">
        <h5 class="font-weight-semibold">Report Summary</h5> <span class="ms-auto">Updated Report</span> <button class="btn btn-icons border-0 p-2"><i class="icon-refresh"></i></button>
      </div>
    </div>

<?php $this->load->view('template/sidebar'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">Tambah Mainan Baru</h3>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo site_url('mainan/proses_tambah'); ?>">
                        <div class="mb-3">
                            <label for="nama_mainan" class="form-label">Nama Mainan:</label>
                            <input type="text" class="form-control" id="nama_mainan" name="nama_mainan" required>
                        </div>
                        <div class="mb-3">
                            <label for="stok" class="form-label">Stok:</label>
                            <input type="number" class="form-control" id="stok" name="stok" min="0" value="0" required>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga:</label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="text" class="form-control" id="harga" name="harga" pattern="^\d+(\.\d{1,2})?$" placeholder="Contoh: 10000 atau 10000.50" required>
                            </div>
                            <small class="form-text text-muted">Masukkan harga dalam format angka (gunakan titik sebagai pemisah desimal).</small>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <a href="<?php echo site_url('mainan'); ?>" class="btn btn-secondary">Kembali ke Daftar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<?php $this->load->view('template/footer'); ?>


