<?php $this->load->view('template/head'); ?>

  
<?php $this->load->view('template/sidebar'); ?>

       <div class="card-body">
            <h5 class="card-title">MAINAN</h5>
            <a href="<?php echo base_url('index.php/mainan/tambah'); ?>" class="btn btn-primary mb-3">Tambah Mainan</a>
            <div class="table-responsive" style="overflow-x: auto;">
              <table class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>ID</th>
                <th>Nama Mainan</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (empty($mainan)): ?>
                <tr><td colspan="5" class="no-data">Tidak ada data mainan.</td></tr>
            <?php else: ?>
                <?php foreach ($mainan as $row): ?>
                    <tr>
                        <td><?php echo $row->id; ?></td>
                        <td><?php echo $row->nama_mainan; ?></td>
                        <td><?php echo $row->stok; ?></td>
                        <td><?php echo number_format($row->harga, 2, ',', '.'); ?></td>
                        <td class="actions">
                            <a href="<?php echo site_url('mainan/edit/' . $row->id); ?>">Edit</a>
                            <a href="<?php echo site_url('mainan/hapus/' . $row->id); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</body>
    </div>
</div>
</div>
<?php $this->load->view('template/footer'); ?>