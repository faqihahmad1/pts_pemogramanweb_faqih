<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mainan extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('M_mainan');
        $this->load->library('form_validation');
        $this->load->helper('url');
    }

    public function index() {
        $data['mainan'] = $this->M_mainan->getAllMainan();
        $this->load->view('v_list_mainan', $data);
    }

    public function tambah() {
        // Logika untuk menampilkan form tambah mainan
        $this->load->view('v_tambah_mainan');
    }

    public function proses_tambah() {
        // Konfigurasi validasi form
        $this->form_validation->set_rules('nama_mainan', 'Nama Mainan', 'required|trim');
        $this->form_validation->set_rules('stok', 'Stok', 'required|integer|min_length[0]');
        $this->form_validation->set_rules('harga', 'Harga', 'required|regex_match[/^\d+(\.\d{1,2})?$/]');

        if ($this->form_validation->run() == FALSE) {
            // Jika validasi gagal, kembalikan ke form tambah mainan
            $this->load->view('template/head');
            $this->load->view('v_tambah_mainan');
            $this->load->view('template/sidebar');
            $this->load->view('template/footer');
        } else {
            // Jika validasi berhasil, masukkan data ke database
            $data = array(
                'nama_mainan' => $this->input->post('nama_mainan'),
                'stok'       => $this->input->post('stok'),
                'harga'      => $this->input->post('harga'),
                          );

            $this->M_mainan->tambahMainan($data);
            $this->session->set_flashdata('success', 'Mainan berhasil ditambahkan.');
            redirect('mainan');
        }
    }

    public function edit($id) {
        $data['mainan'] = $this->M_mainan->getMainanById($id);

        if (empty($data['mainan'])) {
            $this->session->set_flashdata('error', 'Mainan tidak ditemukan.');
            redirect('mainan');
        }

        $this->load->view('v_edit_mainan', $data);
    }

    public function proses_edit($id) {
        $this->form_validation->set_rules('nama_mainan', 'Nama Mainan', 'required|trim');
        $this->form_validation->set_rules('stok', 'Stok', 'required|integer|min_length[0]');
        $this->form_validation->set_rules('harga', 'Harga', 'required|regex_match[/^\d+(\.\d{1,2})?$/]');

        if ($this->form_validation->run() == FALSE) {
            $data['mainan'] = $this->M_mainan->getMainanById($id);
            $this->load->view('v_edit_mainan', $data);
        } else {
            $data = array(
                'nama_mainan' => $this->input->post('nama_mainan'),
                'stok'       => $this->input->post('stok'),
                'harga'      => $this->input->post('harga'),
                            );

            $this->M_mainan->updateMainan($id, $data);
            $this->session->set_flashdata('success', 'Mainan berhasil diubah.');
            redirect('mainan');
        }
    }

    // Metode-metode lain seperti hapus (jika ada)
}
