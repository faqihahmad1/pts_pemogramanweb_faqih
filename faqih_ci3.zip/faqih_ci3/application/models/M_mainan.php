<?php

class M_mainan extends CI_Model {

    private $table = 'mainan';

    public function getAllMainan() {
        return $this->db->get($this->table)->result();
    }

    public function tambahMainan($data) {
        return $this->db->insert($this->table, $data);
    }

    public function getMainanById($id) {
        return $this->db->get_where($this->table, ['id' => $id])->row();
    }

    public function updateMainan($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update($this->table, $data);
    }

    public function hapusMainan($id) {
        $this->db->where('id', $id);
        return $this->db->delete($this->table);
    }
}