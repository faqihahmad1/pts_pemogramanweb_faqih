<?php
class Produk extends CI_Model {
  public function get(){
    return $this->db->get('produk')->result();
  }
}