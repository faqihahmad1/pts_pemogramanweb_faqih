<?php
class faqih_m extends CI_Model {
  public function get()
  {
    return $this->db->get('bio')->result();
  }
}